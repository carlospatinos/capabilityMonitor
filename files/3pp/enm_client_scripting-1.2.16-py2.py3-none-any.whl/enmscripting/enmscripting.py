#!/usr/bin/python -tt
# To make Py2 code safer (more like Py3) by preventing implicit relative imports
from __future__ import absolute_import
import requests
try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode
from .terminal import *
from .command import *

requests.packages.urllib3.disable_warnings()

"""
enm module  - allows execution of enm cli commands to an enm deployment
            - commands are entered as strings, including all parameters, as per entering a command in the web-cli
            - file import is supported as an optional parameter to be added to the execute function
            - the command result returned contains the result data as a list of Strings
            - the result also contains the http-response code and a file if the command exports a file
    Sample usage :
    session = enm.open("https://url.to.enm/","user","password")
    response = session.terminal().execute("cmedit get * ENodeBFunction.*")
    for line in response.get_output():
        print line
    enm.close(session)
"""


def open(url, username, password):
    """
    Opens a connection towards ENM CLI.

    The connection should be closed using close() if it is not required anymore.

    :param url:                 url of the enm deployment
    :param username:            username
    :param password:            password

    :raise: ValueError if username or password is invalid
            requests.exceptions.ConnectionError if there is an issue with the connection

    :return:                    EnmSession
    """
    logging.info('ENM opening session: ' + url + ' ' + username)

    session = EnmSession(url)
    session._open_session(username, password)

    logging.info('ENM session is open: ' + url + ' ' + username + ' ' + str(session))
    return session


def close(enm_session):
    """
    Closes the session to free the underling resources
    :param EnmSession:    EnmSession instance to be closed. This will terminate the Session contained
                          in this instance
    :return:              boolean, true if successfully closed
    """
    logging.info('ENM closing session: ' + str(enm_session))

    enm_session._close_session()

    logging.info('ENM session is closed: ' + str(enm_session))


class EnmSession():
    """
    This class holds a session to a running ENM deployment
    """
    _se_login_headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                         'Content-Type': 'application/x-www-form-urlencoded'}

    def __init__(self, url):
        self._url = url
        self._uri_se_login = self._url + '/login'
        self._session = requests.Session()
        self._terminal = EnmTerminal(self._url, self._session)
        self._command = EnmCommand(self._url, self._session)

    def terminal(self):
        """
        Returns an instance of EnmTerminal
        """
        return self._terminal

    def command(self):
        """
        Returns an instance of EnmCommand
        """
        return self._command

    # Private methods from module's perspective
    def _open_session(self, username, password):
        """
        Opens a session towards ENM CLI.

        :param url:             url of the enm deployment
        :param username:        username
        :param password:        password
        """
        logging.debug('Opening session: ' + str(self))

        self.username = username

        self.se_open_request_body = {
            'IDToken1': self.username,
            'IDToken2': password,
            'goto': self._uri_se_login,
            'gotoOnFail': self._uri_se_login + '/?goto=' + urlencode(
                {'url': self._uri_se_login}) + '&login=fail&user=' + self.username}

        r = self._session.post(
            self._uri_se_login,
            headers=self._se_login_headers,
            data=self.se_open_request_body,
            verify=False, allow_redirects=False)

        # logging.debug('Login server response is: ' + r.text.encode('utf-8'))

        if 'x-autherrorcode' not in r.headers:
            logging.error('Failed to open session.')
            logging.debug('Http status code from server is: ' + str(r.status_code))
            logging.debug('Response header is: ' + str(r.headers))
            raise ValueError('Invalid login: ' + username + '. Response code from server is: ' + str(r.status_code))
        elif r.headers['x-autherrorcode'] is not '0':
            logging.error('Failed to open session, credentials are invalid.')
            logging.debug('Http status code from server is: ' + str(r.status_code))
            logging.debug('Response header is: ' + str(r.headers))
            raise ValueError(
                'Invalid login, credentials are invalid for user: ' + username + '. Response code from server is: ' +
                str(r.status_code))

        logging.debug('Session opened: ' + str(self))

        return True

    def _close_session(self):
        logging.debug('Closing session: ' + str(self))
        url_logout = self._url + '/logout'
        self._session.get(url_logout, verify=False, allow_redirects=True)
        # logging.debug('Server response is: ' + r.text.encode('utf-8'))
        logging.debug('Session is closed: ' + str(self))
