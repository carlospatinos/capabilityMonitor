#!/usr/bin/python -tt
import logging
from .element import *
from .output import Output
from .executionhandler import *
from .exceptions import IllegalStateException


class EnmCommand():
    """
    This class allows for the execution of a CLI command towards an ENM deployment. The return is a
    CommandOutput instance which holds the converted results
    """

    _SERVER_VERSION = 'VERSION=\"1\"'
    _CONTENT_TYPE = "application/vnd.com.ericsson.oss.scripting.command+json"
    _MEDIA_TYPE = _CONTENT_TYPE + ';' + _SERVER_VERSION

    def __init__(self, url, session):
        self._handler = ExecutionHandler(url, session, self._MEDIA_TYPE)

    def execute(self, command_str, file=None, timeout_seconds=600):
        """
        :param command_str:      command to be executed. For more information about a command's syntax, please
                                    check the web-cli online help
        :param file:             file object to be imported  - optional parameter
                                    - needed if the command requires a file for upload
        :param timeout_seconds:
        :return:                 CommandOutput instance
        """
        logging.debug('Executing EnmCommand command...')

        (response_text, response_code, success) = self._handler.execute(command_str, file, timeout_seconds)

        return CommandOutput(response_text, response_code, success, self._handler)


class CommandOutput(Output):
    """
    Class representing the output of the command execution in an object-friendly format
    """

    _OUTPUT = 'output'
    _COMMAND = 'command'
    _VERSION = 'v'

    def __init__(self, json_response, http_code, success, handler=None):
        """
        :param json_response:   command response in json format
        :param http_code:       http_response code
        :param success:
        :param command:
        :return:
        """
        super(CommandOutput, self).__init__(json_response, http_code, success)

        self._handler = handler

        self._command = None
        self._output = None
        self._files_cache = None

        # Extract command string from JSON response
        if success and json_response is not None:
            if self._COMMAND in self._parsed_json.keys():
                self._command = self._parsed_json[self._COMMAND]

    def has_files(self):
        """
        :return boolean: true if there are files in the response
        """
        return len(self.files()) > 0

    def files(self):
        """
        Gets all of the file elements in the output of the command

        :return ElementGroup: file elements
        """
        if self._files_cache is None:
            self._files_cache = self.get_output()._find_by_type(FileElement)
        return self._files_cache

    def get_output(self):
        """
        Gets the output of the command

        :return ElementGroup: the output of the command
        """
        logging.debug('get_output()')

        if not self._success:
            logging.warn('There is no output to parse, because command execution failed: raising IllegalStateException')
            raise IllegalStateException('There is no output to parse, because command execution failed')

        if self._output is None:
            self._output = self._create_elements(self._parsed_json[self._OUTPUT])

        return self._output

    def _create_elements(self, output_json):
        """
        Recursive method to create the elements from the JSON.

        JSON contains elements. Each element can be an Element or GroupElement.
        Each GroupElement can contain Elements and GroupElements, therefore recursive parsing is required.
        """
        type = output_json[Element.KEY_TYPE]

        if type == TextElement.TYPE:
            # Leaf element
            return TextElement(output_json)
        elif type == FileElement.TYPE:
            # Leaf element
            return FileElement(output_json, self._handler)
        elif type == ElementGroup.TYPE:
            # Recursive call with each item
            items = map(lambda e: self._create_elements(e), output_json[ElementGroup.KEY_ITEMS])
            output_json[ElementGroup.KEY_ITEMS] = items
            group = ElementGroup(output_json)
            return group
        else:
            # New DTO
            return Element(output_json)
