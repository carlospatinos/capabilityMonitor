#!/usr/bin/python -tt
import logging
import json
from .exceptions import InternalError


class Output(object):
    """
    Base class representing the output from a command
    """
    def __init__(self, json_response, http_code, success):
        self._http_response_code = http_code
        self._success = success

        if success and json_response is not None:
            self._json = json_response
            try:
                self._parsed_json = json.loads(self._json)
            except ValueError as ex:
                logging.warn('Illegal server response: response is not in JSON format')
                raise InternalError('Illegal server response: response is not in JSON format', ex)

    def http_response_code(self):
        """
        :return:                http_response code from the underlying request
        """
        return self._http_response_code

    def is_success_sent(self):
        """
        :return:                boolean, true if the request was successfully sent to the ENM server
        """
        return self._success
