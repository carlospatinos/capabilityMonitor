from .json_generator import *
from nose.tools import assert_raises
from enmscripting.command import CommandOutput
from enmscripting.exceptions import IllegalStateException
import logging

logging.basicConfig(level=logging.DEBUG)


def test_create_command_output_with_command():
    json = generate_json(0, 0, 0, 0, 0)
    result = CommandOutput(json, 200, True)
    assert result._command == COMMAND


def test_command_output_error_status():
    json = generate_json(0, 0, 0, 0, 0)
    result = CommandOutput(json, 200, False)
    assert_raises(IllegalStateException, result.get_output)
