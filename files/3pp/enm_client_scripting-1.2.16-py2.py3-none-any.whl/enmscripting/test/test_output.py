from nose.tools import assert_raises
from .json_generator import *
from enmscripting.output import Output
from enmscripting.exceptions import InternalError


def test_output():
    out = Output(None, 200, True)
    assert out.http_response_code() == 200
    assert out.is_success_sent() is True


def test_output_good_json():
    json = generate_json(0, 0, 0, 0, 0)
    output = Output(json, 200, True)
    assert output._parsed_json is not None, 'expecting Output to have _parsed_json. There is none.'


def test_create_command_output_bad_json():
    bad_json = r"'elements' : []"
    try:
        result = Output(bad_json, 200, True)
        assert False, 'Should throw InternalError'
    except InternalError:
        pass
