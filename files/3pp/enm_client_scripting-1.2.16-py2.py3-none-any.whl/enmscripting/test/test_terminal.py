from mock import MagicMock, ANY
from nose.tools import assert_raises
from enmscripting.terminal import TerminalOutput
from enmscripting.exceptions import (IllegalStateException, InternalError)
import logging

logging.basicConfig(level=logging.DEBUG)


def test_terminal_output_lines():
    json_output = construct_result_string(_LINE_RESULT)
    output = TerminalOutput(json_output, 200, True)
    lines = output.get_output()
    assert len(lines) == 1, 'Output size should be 1'


def test_terminal_output_empty_not_ignored():
    json_output = construct_result_string(_LINE_RESULT_EMPTY_LINE)
    output = TerminalOutput(json_output, 200, True)
    lines = output.get_output()
    assert len(lines) == 3, 'Wrong output size of : ' + str(len(lines))


def test_terminal_output_table():
    json_output = construct_result_string(_TABLE_RESULT)
    output = TerminalOutput(json_output, 200, True)
    lines = output.get_output()
    # Header row + 1 Value row = 2
    assert len(lines) == 2, 'Output size should be 2, found : ' + str(len(lines))
    # Assert header row comes first
    assert lines[0].startswith('Name') is True
    # Assert each row contains TABs
    for line in lines:
        assert ('\t' in line) is True, 'Line should contain TABs'


def test_terminal_output_lines_and_tables():
    data_string = _LINE_RESULT + '\\n' + _LINE_RESULT + '\\n' + _TABLE_RESULT + _LINE_RESULT + '\\n' + _TABLE_RESULT
    json_output = construct_result_string(data_string)
    output = TerminalOutput(json_output, 200, True)
    lines = output.get_output()
    # Length is: 1 + 1 + 2 + 1 + 2 = 7
    assert len(lines) == 7, 'Output size should be 7'


def test_not_success_raises_exception():
    output = TerminalOutput(None, 200, False)
    assert_raises(IllegalStateException,  output.get_output)


def test_response_incorrect_format():
    result_string_incorrect = '{"NOToutput": "success lines"}'
    output = TerminalOutput(result_string_incorrect, 200, True)
    assert_raises(InternalError,  output.get_output)


def test_response_not_proper_json():
    result_string_not_proper_json = \
        '{"output" : "commmand as ok", ' \
        '"v" : "1"' \
        ''  # '}' missing from the end
    try:
        output = TerminalOutput(result_string_not_proper_json, 200, True)
        assert False, 'Should throw InternalError'
    except InternalError:
        pass


def test_execute_download_has_files_pos():
    """
    Test the scenario when the response contains a 'download' response
    """
    cmd_output = TerminalOutput(DOWNLOAD_RESPONSE, 200, True)
    assert cmd_output.has_files() is True


def test_execute_download_get_files():
    terminal = MagicMock()
    cmd_output = TerminalOutput(DOWNLOAD_RESPONSE, 200, True, terminal)
    files = cmd_output.files()

    assert files, "expected a list of files"
    assert len(files) == 1, "expected 1 file, found :" + str(len(files))


def test_execute_download_get_files_with_no_files():
    cmd_output = TerminalOutput(construct_result_string(_LINE_RESULT), 200, True)
    files = cmd_output.files()

    assert files is not None, "expected a list of files"
    assert len(files) == 0, "expected 0 files, found :" + str(len(files))


def test_execute_download_has_files_neg():
    """
    Test the scenario when the response contains no 'download' response
    """
    cmd_output = TerminalOutput(construct_result_string(_LINE_RESULT), 200, True)
    assert cmd_output.has_files() is False


_RESULT_PREFIX = '{"output":"'

_RESULT_POSTFIX = '","v":"1"}'

_LINE_RESULT = '2 instance(s)'

_LINE_RESULT_EMPTY_LINE = '\\n' \
                          '2 instance(s)\\n' \
                          '\\n'

_TABLE_RESULT = 'Name' \
                '\\tDescription' \
                '\\tNamespace' \
                '\\n' \
                'MeContext' \
                '\\tThis MO can be the root MO of the mirror.' \
                '\\tOSS_TOP' \
                '\\t2.0.0\\n'

DOWNLOAD_RESPONSE = _RESULT_PREFIX + '", "attachments": [' \
                                     '{"applicationId":"scripting",' \
                                     '"fileId": "1010"}' \
                                     '], "v":"0"}'


def construct_result_string(data_string):
    return _RESULT_PREFIX + data_string + _RESULT_POSTFIX
