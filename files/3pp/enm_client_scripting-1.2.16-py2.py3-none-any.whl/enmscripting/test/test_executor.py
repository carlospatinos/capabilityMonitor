import io
import requests
import os
from nose.tools import assert_raises
from requests.exceptions import ConnectionError
from enmscripting.file import FileResult
from enmscripting.exceptions import TimeoutException
from enmscripting.executionhandler import ExecutionHandler
from enmscripting.command import EnmCommand
from mock import MagicMock, ANY, patch
import logging

logging.basicConfig(level=logging.DEBUG)

_MEDIA_TYPE = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
_FILE_PATH = './abc.txt'


def test_execute_post():
    handler = ExecutionHandler('some url', None, _MEDIA_TYPE)
    set_command_mock(handler)
    handler.execute('command')
    handler._session.post.assert_called_with(
        ANY, headers=ANY, files=ANY, data=None, verify=False, allow_redirects=False)


def test_command_post_with_file():
    handler = ExecutionHandler('some url', None, _MEDIA_TYPE)
    set_command_mock(handler)

    with io.open("valid.txt", "wb+") as fileUpload:
        fileUpload.write(b'dummyNode')
        handler.execute('secadm command file:valid.txt', fileUpload)
        handler._session.post.assert_called_with(
            ANY, headers=ANY, files=ANY, data=ANY, verify=False, allow_redirects=False)

    if os.path.isfile(fileUpload.name):
        os.remove(fileUpload.name)


def test_command_post_with_invalid_file():
    handler = ExecutionHandler('some url', None, _MEDIA_TYPE)
    set_command_mock(handler)

    with io.open("valid2.txt", "wb+") as fileUpload:
        fileUpload.write(b'dummyNode')
        assert_raises(ValueError, handler.execute, 'secadm command file:invalid.txt', fileUpload)

    if os.path.isfile(fileUpload.name):
        os.remove(fileUpload.name)


def test_execute_post_bad_status_line():
    with patch.object(requests.session(), 'post') as session:
        session.post.side_effect = [ConnectionError(ExecutionHandler._ERROR_BAD_STATUS_LINE),
                                    get_response()]
        handler = ExecutionHandler('some url', session, _MEDIA_TYPE)
        handler.execute('command')

        assert handler._session.post.call_count is 2
        session.post.assert_called_with(ANY, headers=ANY, files=ANY, data=None, verify=False, allow_redirects=False)


def test_execute_post_exception():
    conn_error = ConnectionError('connection error')
    with patch.object(requests.session(), 'post') as session:
        session.post.side_effect = conn_error
        handler = ExecutionHandler('some url', session, _MEDIA_TYPE)
        assert_raises(ConnectionError, handler.execute, 'command')
        assert session.post.call_count is 1


def test_download():
    with patch.object(requests.session(), 'get') as session:
        session.post.side_effect = requests.Response()
        handler = ExecutionHandler('some url', session, _MEDIA_TYPE)
        handler.download(1, 1, _FILE_PATH)

        handler._session.get.assert_called_with(ANY, headers=ANY, verify=False, stream=True)

    os.remove(_FILE_PATH)


def test_get_bytes():
    with patch.object(requests.session(), 'get') as session:
        session.post.side_effect = requests.Response()
        handler = ExecutionHandler('some url', session, _MEDIA_TYPE)
        handler.get_bytes(1, 1)

        handler._session.get.assert_called_with(ANY, headers=ANY, verify=False, stream=True)


class File():
    def __init__(self, name):
        self.name = name


def test_get_file_name_positive():
    handler = ExecutionHandler('some url', None, None)
    file = File('valid.txt')
    assert handler._get_file_name('somecommand file:valid.txt', file) == file.name


def test_get_file_name_negative():
    handler = ExecutionHandler('some url', None, None)
    file = File('invalid.txt')
    assert_raises(ValueError, handler._get_file_name, 'somecommand file:valid.txt', file)


def test_command_get():
    handler = ExecutionHandler('some url', None, _MEDIA_TYPE)
    set_command_mock(handler)

    response_size = str(100)
    handler._command_get(response_size)

    handler._session.get.assert_called_with(
        handler._urls[ExecutionHandler._KEY_GET] + str(response_size), headers=ANY, verify=False, allow_redirects=False)


def test_command_get_response_size():
    handler = ExecutionHandler('some url', None, _MEDIA_TYPE)
    set_command_mock(handler)

    response = handler._command_poll(5)

    handler._session.head.assert_called_with(ANY, headers=ANY, verify=False, allow_redirects=False)
    assert response.headers['responsesize'] == 10, 'response should be 10'


def test_command_get_no_response_size():
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_command_mock(handler, responsesize=None)

    assert_raises(TimeoutException, handler._command_poll, 1)


def test_command_poll_timeout():
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_command_mock(handler, commandstatus='RUNNING')

    assert_raises(TimeoutException, handler._command_poll, 1)


def test_execute_positive():
    """
    Test the scenario when the all 3 requests succeed
    """
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_mock_http_codes(handler, 201, 200, 200)
    result = handler.execute('command')
    assert result[2] is True


def test_execute_post_fails():
    """
    Test the scenario when the first request (post) in the method 'execute'  fails
    """
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_mock_http_codes(handler, 404, 200, 200)
    result = handler.execute('command')
    assert result[2] is False


def test_execute_poll_fails():
    """
    Test the scenario when the second request (poll) in the method 'execute'  fails
    """
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_mock_http_codes(handler, 201, 404, 200)
    result = handler.execute('command')
    assert result[2] is False


def test_execute_get_fails():
    """
    Test the scenario when the third request (get) in the method 'execute'  fails
    """
    media_type = "application/vnd.com.ericsson.oss.scripting.command+json;VERSION=\"1\""
    handler = ExecutionHandler('some url', None, media_type)
    set_mock_http_codes(handler, 201, 200, 404)
    result = handler.execute('command')
    assert result[2] is False


def test_file_result_get_name():
    """
    Test that FileResult.get_name() returns what is expected in various cases
    """
    test_file_names = [
        ("myfile.txt", "myfile.txt"),
        ("myfile", "myfile"),
        ("/some/path/myfile.txt", "myfile.txt"),
        ("some/path/myfile.txt", "myfile.txt"),
        ("///some/path/myfile.txt", "myfile.txt"),
        ("///myfile.txt", "myfile.txt")
    ]

    for data, expected_output in test_file_names:
        object_under_test = FileResult("", data, MagicMock())
        assert object_under_test.get_name() == expected_output, \
            "expected {0}, got {}".format(expected_output, object_under_test.get_name())


def test_file_result_delegate_no_path():
    """
    Test that FileResult.download() delegates the implementation to EnmTerminal
    """
    handler = MagicMock()
    object_under_test = FileResult("app", "file", handler)
    object_under_test.download()
    handler.download.assert_called_with('app', 'file', 'file')


def test_file_result_delegate_with_path():
    """
    Test that FileResult.download() delegates the implementation to EnmTerminal
    """
    terminal = MagicMock()
    terminal.download = MagicMock()
    object_under_test = FileResult("app", "file", terminal)
    object_under_test.download('some/path')
    terminal.download.assert_called_with('app', 'file', 'some/path')


def test_get_bytes_result_delegate():
    """
    Test that FileResult.get_bytes() delegates the implementation to EnmTerminal
    """
    terminal = MagicMock()
    terminal.download = MagicMock()
    object_under_test = FileResult("app", "file", terminal)
    object_under_test.get_bytes()
    terminal.get_bytes.assert_called_with('app', 'file')


def test_command_execute_handler_delegate():
    """
    Test that FileResult.get_bytes() delegates the implementation to EnmTerminal
    """
    _session = MagicMock()
    object_under_test = EnmCommand("app", _session)
    object_under_test._handler = MagicMock()
    object_under_test._handler.execute.return_value = (NORMAL_RESPONSE, 200, True)
    object_under_test.execute("aaa")
    object_under_test._handler.execute.assert_called_with('aaa', None, 600)


def get_response(responsesize=10, commandstatus='COMPLETE'):
    response = MagicMock()
    response.headers = {'x-autherrorcode': 0}
    if responsesize is not None:
        response.headers['responsesize'] = responsesize
    response.headers['commandstatus'] = commandstatus
    return response


def set_command_mock(handler, responsesize=10, commandstatus='COMPLETE'):
    response = get_response(responsesize, commandstatus)

    _session = MagicMock()
    _session.post.return_value = response
    _session.get.return_value = response
    _session.head.return_value = response

    handler._session = _session
    return response


def set_mock_http_codes(handler, post_res_code, poll_res_code, get_res_code):
    r1 = MagicMock()
    r1.status_code = post_res_code
    r2 = MagicMock()
    r2.status_code = poll_res_code
    r3 = MagicMock()
    r3.status_code = get_res_code
    r3.text = None

    handler._command_post = MagicMock(return_value=r1)
    handler._command_poll = MagicMock(return_value=r2)
    handler._command_get = MagicMock(return_value=r3)

    return r1, r2, r3


NORMAL_RESPONSE = '{"nonCachableDtos":[],"responseDto":' \
                  '{"dtoType":"ResponseDto","elements":[{"dtoType":"line","value":"1 instance(s)","dtoName":null},' \
                  '{"dtoType":"line","value":"","dtoName":null},{"dtoType":"line","value":null,"dtoName":null},' \
                  '{"dtoType":"line","value":"FDN : MeContext=LTE09ERBS00002","dtoName":null},' \
                  '{"dtoType":"command","value":"cmedit get * MeContext","dtoName":null}],"dtoName":null}}'
