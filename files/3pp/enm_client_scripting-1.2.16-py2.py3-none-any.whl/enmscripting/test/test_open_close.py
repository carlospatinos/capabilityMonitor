from mock import MagicMock, ANY
from enmscripting.enmscripting import EnmSession
from enmscripting.terminal import EnmTerminal
import logging
from nose.tools import assert_raises

logging.basicConfig(level=logging.DEBUG)

test_url = 'mock://abc.com'


def test_open_enm_session():
    enm_session = EnmSession(test_url)
    mock_enm_session(enm_session, '0')
    assert enm_session._open_session('username', 'password')

    assert_login_post(enm_session)


def test_close_enm_session():
    enm_session = EnmSession(test_url)
    mock_enm_session(enm_session, '0')
    enm_session._close_session()

    assert enm_session._session.get.called
    assert not enm_session._session.post.called
    enm_session._session.get.assert_called_with(test_url + '/logout', verify=False, allow_redirects=True)


def test_open_enm_session_authentication_failed_no_auth_code():
    enm_session = EnmSession(test_url)
    mock_enm_session(enm_session, None)
    assert_raises(ValueError, enm_session._open_session, 'username', 'password')

    assert_login_post(enm_session)


def test_open_enm_session_authentication_failed_auth_code_not_1():
    enm_session = EnmSession(test_url)
    mock_enm_session(enm_session, '-1')
    assert_raises(ValueError, enm_session._open_session, 'username', 'password')

    assert_login_post(enm_session)


def test_open_enm_session_authentication_failed_auth_code_minus_2():
    enm_session = EnmSession(test_url)
    mock_enm_session(enm_session, '-2')
    assert_raises(ValueError, enm_session._open_session, 'username', 'password')

    assert_login_post(enm_session)


def test_enm_session_has_terminal():
    enm_session = EnmSession('mock://abc.com')
    terminal = enm_session.terminal()
    assert isinstance(terminal, EnmTerminal)


def mock_enm_session(enm_session, xautherror_code):
    m_session = MagicMock()
    m_login_resp = MagicMock()
    m_login_resp.text = 'mockLoginResponse'
    m_login_resp.headers = {}
    if (xautherror_code is not None):
        m_login_resp.headers['x-autherrorcode'] = xautherror_code
    m_session.post.return_value = m_login_resp

    m_logout_resp = MagicMock()
    m_logout_resp.text = 'mockLogoutResponse'
    m_session.get.return_value = m_logout_resp

    enm_session._session = m_session


def assert_login_post(enm_session):
    assert not enm_session._session.get.called
    assert enm_session._session.post.called
    enm_session._session.post.assert_called_with(test_url + '/login',
                                                 verify=False, allow_redirects=False, data=ANY, headers=ANY)
