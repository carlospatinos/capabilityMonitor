#!/usr/bin/python -tt
import logging
import io
from time import sleep
import requests
from .exceptions import *


class ExecutionHandler():
    """
    Class to contain the execution of the ENM Command.
    """

    # SERVER-SCRIPTING URLS
    _URL_SS_ROOT = '/server-scripting/services/'
    _URL_SS_FILE = _URL_SS_ROOT + 'file'
    _URL_SS_COMMAND = _URL_SS_ROOT + 'command/'
    _URL_SS_COMMAND_OUTPUT_0 = _URL_SS_COMMAND + 'output/0/'
    _URL_SS_COMMAND_STATUS = _URL_SS_COMMAND + 'status'

    # Is command completed
    _COMMAND_STATUS = 'commandstatus'
    _COMMAND_RESPONSE_SIZE = 'responsesize'
    _COMMAND_COMPLETE = 'COMPLETE'

    # Requests error message
    _ERROR_BAD_STATUS_LINE = '(\'Connection aborted.\', BadStatusLine(\"\'\'\",))'

    # Post data keys: req_data / file_data
    _POST_DATA_NAME = 'name'
    _POST_DATA_FILE = 'file:'
    _POST_DATA_COMMAND = 'command'
    _POST_DATA_FILE_NAME = 'fileName'

    # Headers
    _HEADER_ACCEPT_KEY = 'Accept'
    _HEADER_REQUESTED_WITH_KEY = 'X-Requested-With'
    _HEADER_REQUESTED_WITH_VALUE = 'XMLHttpRequest'
    _HEADER_ACCEPT_ENCODING_KEY = 'Accept-Encoding'
    _HEADER_ACCEPT_ENCODING_VALUE = ', '.join(('gzip', 'deflate', 'sdch'))

    _CONTENT_TYPE_FILE = "application/octet-stream"
    _CONTENT_TYPE_TEXT = "application/vnd.com.ericsson.oss.scripting+text;VERSION=\"1\""

    _KEY_GET = 'get'
    _KEY_POLL = 'poll'
    _KEY_POST = 'post'
    _KEY_FILES = 'files'

    def __init__(self, url, session, media_type):
        """
        Default
        """
        self._session = session
        self._content_type_get = media_type

        self._headers = {self._KEY_GET: self._header(self._content_type_get),
                         self._KEY_POLL: self._header(self._CONTENT_TYPE_TEXT, True),
                         self._KEY_POST: self._header(self._CONTENT_TYPE_TEXT),
                         self._KEY_FILES: self._header(self._CONTENT_TYPE_FILE)}
        self._urls = {self._KEY_GET: url + self._URL_SS_COMMAND_OUTPUT_0,
                      self._KEY_POLL: url + self._URL_SS_COMMAND_STATUS,
                      self._KEY_POST: url + self._URL_SS_COMMAND,
                      self._KEY_FILES: url + self._URL_SS_FILE}

        self._verify = False
        self._allow_redirects = False

    def execute(self, command_str, file=None, timeout_seconds=600):
        """
        :param command_str:      command to be executed. For more information about a command's syntax, please
                                 check the web-cli online help
        :param file:             file object to be imported  - optional parameter -
                                 needed if the command requires a file for upload
        :param timeout_seconds:
        :return:                 CommandOutput instance
        """
        logging.debug('Starting execution of command....')

        response = self._command_post(command_str, file)
        if response.status_code is not 201:
            logging.warning('se_command_post failed')
            return response.text, response.status_code, False

        response = self._command_poll(timeout_seconds)
        if response.status_code is not 200:
            logging.warning('se_poll_result_head failed')
            return response.text, response.status_code, False

        response = self._command_get(response.headers[self._COMMAND_RESPONSE_SIZE])
        if response.status_code is not 200:
            logging.warning('se_get_result failed')
            return response.text, response.status_code, False

        logging.debug('Command executed successfully: ' + command_str)

        return response.text, response.status_code, True

    def download(self, application_id, file_id, path):
        logging.debug('Downloading file from ENM')
        response = self._command_download(application_id, file_id)
        with io.open(path, 'wb') as handle:
            for block in response.iter_content(1024):
                if not block:
                    break
                handle.write(block)
            logging.debug('Wrote file {0} to disk'.format(path))

    def get_bytes(self, application_id, file_id):
        logging.debug('Downloading file from ENM')
        response = self._command_download(application_id, file_id)
        buf = bytearray()
        for b in response.iter_content():
            if not b:
                break
            buf.extend(b)
        logging.debug('Wrote {0} bytes to memory'.format(len(buf)))
        return buf

    def _command_post(self, command, file_in=None):
        logging.debug('POST command request')
        file_data, req_data = self._get_post_data(command, file_in)
        try:
            response = self._session_post(file_data=file_data, req_data=req_data)
        except requests.exceptions.ConnectionError as e:
            if str(e) == self._ERROR_BAD_STATUS_LINE:
                logging.debug('Re-trying post request.' + str(e))
                response = self._session_post(file_data=file_data, req_data=req_data)
            else:
                raise e
        logging.debug('POST command request executed')
        return response

    def _command_poll(self, timeout_seconds):
        logging.debug('Polling for command result')

        for i in range(timeout_seconds):
            response = self._session_poll()
            if self._is_command_completed(response.headers):
                logging.debug('Commmand execution completed, returning result')
                logging.debug(response.headers)
                return response
            sleep(1)
            logging.debug('Polling server for response: ' + str(i))

        logging.debug('Command did not complete within the specified timeout [' + str(timeout_seconds) +
                      ' seconds], raising TimeoutException')
        raise TimeoutException(
            'Command did not complete within the specified timeout [' + str(timeout_seconds) + ' seconds]')

    def _command_get(self, response_size):
        logging.debug('GET command result')
        logging.debug('response size: ' + str(response_size))
        response = self._session_get(response_size=response_size)
        logging.debug('GET command result executed')
        return response

    def _command_download(self, application_id, file_id):
        return self._session_files(application_id=application_id, file_id=file_id)

    @classmethod
    def _get_post_data(cls, command, file_in=None):
        if file_in is not None:
            logging.debug('POST command contains file: ' + file_in.name)
            file_name = cls._get_file_name(command, file_in)
            file_data = {cls._POST_DATA_FILE: (file_name, file_in)}
            req_data = {cls._POST_DATA_COMMAND: command, cls._POST_DATA_FILE_NAME: file_name}
        else:
            logging.debug('POST command does not contains file')
            file_data = {cls._POST_DATA_NAME: cls._POST_DATA_COMMAND, cls._POST_DATA_COMMAND: command}
            req_data = None
        return file_data, req_data

    @classmethod
    def _get_file_name(cls, command, file_in):
        file_name = file_in.name
        command_file_part = cls._POST_DATA_FILE + file_name
        if command_file_part not in command:
            raise ValueError("Expected file name 'file:%s' not found in command '%s'" % (file_in.name, command))
        else:
            return file_name

    @classmethod
    def _is_command_completed(cls, headers):
        return cls._COMMAND_RESPONSE_SIZE in headers and headers[cls._COMMAND_STATUS] == cls._COMMAND_COMPLETE

    @classmethod
    def _header(cls, content_type, accept_encoding=False):
        header = {cls._HEADER_REQUESTED_WITH_KEY: cls._HEADER_REQUESTED_WITH_VALUE,
                  cls._HEADER_ACCEPT_KEY: content_type}
        if accept_encoding:
            header[cls._HEADER_ACCEPT_ENCODING_KEY] = cls._HEADER_ACCEPT_ENCODING_VALUE
        return header

    def _session_post(self, file_data, req_data):
        return self._session.post(
            self._urls[self._KEY_POST],
            headers=self._headers[self._KEY_POST],
            files=file_data, data=req_data,
            verify=self._verify, allow_redirects=self._allow_redirects)

    def _session_get(self, response_size):
        return self._session.get(
            self._urls[self._KEY_GET] + response_size,
            headers=self._headers[self._KEY_GET],
            verify=self._verify, allow_redirects=self._allow_redirects)

    def _session_poll(self):
        return self._session.head(
            self._urls[self._KEY_POLL],
            headers=self._headers[self._KEY_POLL],
            verify=self._verify, allow_redirects=self._allow_redirects)

    def _session_files(self, application_id, file_id):
        return self._session.get('{0}/{1}{2}'.format(
            self._urls[self._KEY_FILES], application_id, file_id),
            headers=self._headers[self._KEY_FILES],
            verify=self._verify, stream=True)
